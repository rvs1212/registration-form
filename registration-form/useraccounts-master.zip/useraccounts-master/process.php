<?php

class ProcessData {

	public function __construct($post_data){
		require_once('config.php');
		require 'PHPMailerAutoload.php';
		require 'credentials.php';
		require 'user_validation.php';
		require 'model.php';
    	$this->data = $post_data;

  	}

  	public function processPostData()
  	{
	  	if(isset($this->data)){
			$validation = new UserValidator($this->data);
			$errors = $validation->validateForm();
			if(empty($errors)){	
				$userEmail = $this->data['email'];
				$processModel = new ProcessModel($this->data);
				$result = $processModel->addUserData();
					if($result){
						$this->sendMail($userEmail);
					}else{
						$finalRes = json_encode(array("status"=>0,"msg"=>"Could not save user details!!")); 
						echo $finalRes;
					}
			}else{
				$errRes = json_encode(array("status"=>0,"msg"=>$errors)); 
				echo $errRes;
			}
		}else{
			$errRes = json_encode(array("status"=>0,"msg"=>'No data found!!')); 
			echo $errRes;
		}
  	}


  	private function sendMail($email)
  	{	
  		// $to = $email;
  		// $subject = 'ABC Agency';
  		// $message = 'Congratulations!!! You are registered.';
  		// $from = EMAIL;
  		// $headers = "From:" . $from;
  		// mail($to,$subject,$message,$headers);

  		$mail = new PHPMailer;
		$mail->isSMTP();                                  
		$mail->Host = 'smtp.gmail.com';  				  
		$mail->SMTPAuth = true;                           
		$mail->Username = EMAIL;                 	      
		$mail->Password = PASS;                          
		$mail->SMTPSecure = 'tls';                        
		$mail->Port = 587;                                
		$mail->setFrom(EMAIL);
		$mail->addAddress($email);     					  
		$mail->isHTML(true);                                
		$mail->Subject = 'ABC Agency';
		$mail->Body    = 'Congratulations!!! You are registered.';
		$mail->send();
		if(!$mail->send()) {
			$mailRes = json_encode(array("status"=>0,"msg"=>"User details added and error on sending mail!")); 
		} else {
			$mailRes = json_encode(array("status"=>1,"msg"=>"User details added and mail send successfully")); 
		}
		echo $mailRes;
  	}
	

}
	
	$processData = new ProcessData($_POST);
	$processData->processPostData();

  



