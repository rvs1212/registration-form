<?php 

class UserValidator {

  private $data;
  private $errors = [];
  private static $fields = ['firstname', 'lastname', 'street', 'city','zip', 'state', 'email', 'phonenumber', 'scriptinglanguage', 'slrating', 'otherlanguage', 'olrating', 'databases', 'dbsrating', 'prsnlskill', 'psrating', 'sleval', 'oleval', 'dbeval', 'pseval' ];

  public function __construct($post_data){
    $this->data = $post_data;
  }

  public function validateForm(){

    foreach(self::$fields as $field){
      if(!array_key_exists($field, $this->data)){
        trigger_error("'$field' is not present in the data");
        return;
      }
    }

    $this->validateFirstname();
    $this->validateLastname();
    $this->validateStreet();
    $this->validateCity();
    $this->validateZip();
    $this->validateState();
    $this->validateEmail();
    $this->validatePhoneNmbr();
    $this->validateScriptinglang();
    $this->validateSlrating();
    $this->validateOtherlang();
    $this->validateOlrating();
    $this->validateDatabases();
    $this->validateDbsrating();
    $this->validatePrsnlskill();
    $this->validatePsrating();
    $this->validateSleval();
    $this->validateOleval();
    $this->validateDbeval();
    $this->validatePseval();
    return $this->errors;

  }

  private function validateFirstname(){

    $val = trim($this->data['firstname']);

    if(empty($val)){
      $this->addError('Firstname field cannot be empty');
    } elseif(strlen($val)< 3 || is_numeric($val))  {
        $this->addError('Firstname field must be minimum 3 chars');
    }

  }

  private function validateLastname()
  {
    $val = trim($this->data['lastname']);

    if(empty($val)){
      $this->addError('Lastname field cannot be empty');
    } elseif(strlen($val) < 3 || is_numeric($val)) {
        $this->addError('Lastname field must be minimum 3 chars');
    }
  }

  private function validateStreet()
  {
    $val = trim($this->data['street']);

    if(empty($val)){
      $this->addError('Street field cannot be empty');
    } elseif(strlen($val) < 3|| is_numeric($val))  {
        $this->addError('Street field must be minimum 3 chars');
    }
  }

  private function validateCity()
  {
    $val = trim($this->data['city']);

    if(empty($val)){
      $this->addError('City field cannot be empty');
    } elseif(strlen($val)  < 3  || is_numeric($val)) {
        $this->addError('City field must be minimum 3 chars');
    }
  }

  private function validateZip()
  {
    $val = trim($this->data['zip']);

    if(empty($val)){
      $this->addError('Zip code cannot be empty');
    } elseif(!is_numeric($val) || strlen($val) > 6 || preg_match('/[\'^£$%&*!.()}{@#~?><>,|=_+¬-]/', $val) ) {
        $this->addError('Zip code must be an integer with max 6 numbers');
    }
  }

  private function validateState()
  {
    $val = trim($this->data['state']);
    if(empty($val)){
      $this->addError('State field cannot be empty');
    } elseif( strlen($val) < 3 || !is_string($val) ) {
        $this->addError('State field should have atleast 3 chars');
    }
    
  }

  private function validateEmail()
  {
    $val = trim($this->data['email']);

    if(empty($val)){
      $this->addError('Email field cannot be empty');
    }elseif(!filter_var($val, FILTER_VALIDATE_EMAIL)){
        $this->addError('Email must be a valid email address');
    }
  }

  private function validatePhoneNmbr()
  {
    $val = trim($this->data['phonenumber']);
    if(empty($val)){
      $this->addError('Phonenumber field cannot be empty');
    }elseif( !is_numeric($val) || (strlen($val) < 10 || strlen($val) > 10) || preg_match('/[\'^£$%&*!.()}{@#~?><>,|=_+¬-]/', $val)  ){
        $this->addError( 'Phonenumber must be a valid number');
    }
  }


  private function validateScriptinglang()
  {
    $val = trim($this->data['scriptinglanguage']);
    if(empty($val)){
      $this->addError( 'Please select one scripting language');
    }
  }

  private function validateSlrating()
  {
    $val = trim($this->data['slrating']);
    if(empty($val)){
      $this->addError('Please rate scripting language');
    }
  }

  private function validateOtherlang()
  {
    $val = trim($this->data['otherlanguage']);
    if(empty($val)){
      $this->addError('Please select one other language');
    }
  } 

  private function validateOlrating()
  {
    $val = trim($this->data['olrating']);
    if(empty($val)){
      $this->addError('Please rate other language');
    }
  }

  private function validateDatabases()
  {
    $val = trim($this->data['databases']);
    if(empty($val)){
      $this->addError('Please select one database');
    }
  }

  private function validateDbsrating()
  {
    $val = trim($this->data['dbsrating']);
    if(empty($val)){
      $this->addError('Please rate Database');
    }
  }

  private function validatePrsnlskill()
  {
    $val = trim($this->data['prsnlskill']);
    if(empty($val)){
      $this->addError('Please select one Personal skill');
    }
  }

  private function validatePsrating()
  {
    $val = trim($this->data['psrating']);
    if(empty($val)){
      $this->addError('Please rate Personal skill');
    }
  }

  private function validateSleval()
  {
    $val = trim($this->data['sleval']);

    if(empty($val)){
      $this->addError('Scripting language evaluation field cannot be empty');
    }elseif( !is_numeric($val) || $val > 100 || $val < 0  ){
        $this->addError('Please add scripting language evaluation value between 0 and 100');
    }
  }

  private function validateOleval()
  {
    $val = trim($this->data['oleval']);

    if(empty($val)){
      $this->addError('Scripting language evaluation field cannot be empty');
    }elseif( !is_numeric($val) || $val > 100 || $val < 0  ){
        $this->addError('Please add other language evaluation value between 0 and 100');
    }
  }

  private function validateDbeval()
  {
    $val = trim($this->data['dbeval']);

    if(empty($val)){
      $this->addError('Database evaluation field cannot be empty');
    }elseif( !is_numeric($val) || $val > 100 || $val < 0  ){
        $this->addError( 'Please add database evaluation value between 0 and 100');
    }
  }

  private function validatePseval()
  {
    $val = trim($this->data['pseval']);

    if(empty($val)){
      $this->addError('Personal skill evaluation field cannot be empty');
    }elseif( !is_numeric($val) || ($val > 100) || ($val < 0)  ){ 
        $this->addError( 'Please add Personal skill evaluation value between 0 and 100');
    }
  }

  private function addError( $val){
    $this->errors = $val;
  }

}

?>
