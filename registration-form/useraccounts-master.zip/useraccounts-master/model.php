<?php

/**
 * 
 */
class ProcessModel 
{
	
	public function __construct($post_data)
	{
		$this->data = $post_data;
	}

	public function addUserData()
	{
		require 'config.php';

		$firstname 			= $this->data['firstname'];
		$lastname 			= $this->data['lastname'];
		$street				= $this->data['street'];
		$city				= $this->data['city'];
		$zip				= $this->data['zip'];
		$state				= $this->data['state'];	
		$email 				= $this->data['email'];
		$phonenumber		= $this->data['phonenumber'];
		$scriptinglanguage  = $this->data['scriptinglanguage'];
		$slrating			= $this->data['slrating'];
		$otherlanguage		= $this->data['otherlanguage'];
		$olrating			= $this->data['olrating'];
		$databases			= $this->data['databases'];
		$dbsrating			= $this->data['dbsrating'];
		$prsnlskill			= $this->data['prsnlskill'];
		$psrating			= $this->data['psrating'];
		$sleval				= $this->data['sleval'];
		$oleval				= $this->data['oleval'];
		$dbeval				= $this->data['dbeval'];
		$pseval				= $this->data['pseval'];
		$skillTotal 		= $sleval + $oleval + $dbeval + $pseval;

		$sql = "INSERT INTO users (firstname, lastname, street , city, zip, state,email, phonenumber, script_lang, script_lang_rating, other_lang, other_lang_rating, db_skill, db_skill_rating, personal_skills, personal_skills_rating, sleval, oleval, dbeval, pseval, skill_eval_total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			$stmtinsert = $db->prepare($sql);
			$result = $stmtinsert->execute([$firstname, $lastname, $street, $city, $zip, $state, $email, $phonenumber, $scriptinglanguage, $slrating, $otherlanguage, $olrating, $databases, $dbsrating, $prsnlskill, $psrating, $sleval, $oleval, $dbeval, $pseval, $skillTotal ]);
	
			return $result;
	}


	

}








?>