<?php
require_once('config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div>
	
	<form action="registration.php" method="post">
		<div class="container">
			
			<div class="row">
					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<h1>Registration</h1>
						</div>
					</div>
					
					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<p>Fill up the form with correct values.</p>
						</div>
					</div>
					
					
					<hr class="mb-3">
					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="firstname"><b>First Name</b></label>
							<input class="form-control" id="firstname" type="text" name="firstname" required>
						</div>
						<div class="col-md-6">
							<label for="lastname"><b>Last Name</b></label>
							<input class="form-control" id="lastname"  type="text" name="lastname" required>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="street"><b>Street</b></label>
							<input class="form-control" id="street"  type="text" name="street" required>
						</div>
						<div class="col-md-6">
							<label for="city"><b>City</b></label>
							<input class="form-control" id="city"  type="text" name="city" required>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="zip"><b>Zip</b></label>
							<input class="form-control" id="zip"  type="text" name="zip" required>
						</div>
						<div class="col-md-6">
							<label for="state"><b>State</b></label>
							<input class="form-control" id="state"  type="text" name="state" required>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="email"><b>Email Address</b></label>
							<input class="form-control" id="email"  type="email" name="email" required>
						</div>
						<div class="col-md-6">
							<label for="phonenumber"><b>Phone Number</b></label>
							<input class="form-control" id="phonenumber"  type="text" name="phonenumber" required>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<h3>Skills</h3>
						</div>
					</div>


					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="skillOne"><b>Scripting Language</b></label>
							<select class="form-control" name="skillOne" id="skillOne" required>
							<option value="" selected="">Select</option>
							<?php
							$qry = "SELECT s.`id`,s.`skills` FROM `categories` AS c LEFT JOIN skills AS s ON c.cat_id = s.cat_id
									WHERE c.cat_id = 1";
							foreach ($db->query($qry) as $value) {								
								echo "<option value=$value[id]>$value[skills]</option>";
							}
							?>
							</select>
						</div>
						<div class="col-md-6">
							<label for="skillTwo"><b>Other Language</b></label>
							<select class="form-control" name="skillTwo" id="skillTwo" required>
							<option value="" selected="">Select</option>
							<?php
							$qry = "SELECT s.`id`,s.`skills` FROM `categories` AS c LEFT JOIN skills AS s ON c.cat_id = s.cat_id
									WHERE c.cat_id = 2";
							foreach ($db->query($qry) as $value) {
								echo "<option value=$value[id]>$value[skills]</option>";
							}
							?>
							</select>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label>Rating: </label>
							<label ><input  type="radio" id="scriptinglanguage" name="scriptinglanguage" value="1" required> 1</label>
							<label><input  type="radio" id="scriptinglanguage" name="scriptinglanguage" value="2"> 2</label>
							<label><input  type="radio" id="scriptinglanguage" name="scriptinglanguage" value="3"> 3</label>
							<label><input type="radio" id="scriptinglanguage" name="scriptinglanguage" value="4"> 4</label>
							<label><input  type="radio" id="scriptinglanguage" name="scriptinglanguage" value="5"> 5</label>
						</div>
						<div class="col-md-6">
							<label>Rating: </label>
							<label ><input  type="radio" id="otherlanguage" name="otherlanguage" value="1" required> 1</label>
							<label><input  type="radio" id="otherlanguage" name="otherlanguage" value="2"> 2</label>
							<label><input  type="radio" id="otherlanguage" name="otherlanguage" value="3"> 3</label>
							<label><input type="radio" id="otherlanguage" name="otherlanguage" value="4"> 4</label>
							<label><input  type="radio" id="otherlanguage" name="otherlanguage" value="5"> 5</label>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label for="skillThree"><b>Databases</b></label>
							<select class="form-control" name="skillThree" id="skillThree" required>
							<option value="" selected="">Select</option>
							<?php
							$qry = "SELECT s.`id`,s.`skills` FROM `categories` AS c LEFT JOIN skills AS s ON c.cat_id = s.cat_id
									WHERE c.cat_id = 3";
							foreach ($db->query($qry) as $value) {
								echo "<option value=$value[id]>$value[skills]</option>";
							}
							?>
							</select>
						</div>
						<div class="col-md-6">
							<label for="skillFour"><b>Personal Skills</b></label>
							<select class="form-control" name="skillFour" id="skillFour" required>
							<option value="" selected="">Select</option>
							<?php
							$qry = "SELECT s.`id`,s.`skills` FROM `categories` AS c LEFT JOIN skills AS s ON c.cat_id = s.cat_id
									WHERE c.cat_id = 4";
							foreach ($db->query($qry) as $value) {
								echo "<option value=$value[id]>$value[skills]</option>";
							}
							?>
							</select>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<label>Rating: </label>
							<label ><input  type="radio" id="databases" name="databases" value="1" required> 1</label>
							<label><input  type="radio" id="databases" name="databases" value="2"> 2</label>
							<label><input  type="radio" id="databases" name="databases" value="3"> 3</label>
							<label><input type="radio" id="databases" name="databases" value="4"> 4</label>
							<label><input  type="radio" id="databases" name="databases" value="5"> 5</label>
						</div>
						<div class="col-md-6">
							<label>Rating: </label>
							<label ><input  type="radio" id="psnlSkill" name="psnlSkill" value="1" required> 1</label>
							<label><input  type="radio" id="psnlSkill" name="psnlSkill" value="2"> 2</label>
							<label><input  type="radio" id="psnlSkill" name="psnlSkill" value="3"> 3</label>
							<label><input type="radio" id="psnlSkill" name="psnlSkill" value="4"> 4</label>
							<label><input  type="radio" id="psnlSkill" name="psnlSkill" value="5"> 5</label>
						</div>
					</div>
					

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-6">
							<h3>Skill Category Evaluation</h3>
							<h6><i>(Enter score values between 0 to 100)</i></h6>
						</div>
					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-md-2">
							<label for="sceval"><b>Scripting Language</b></label>
							<input class="form-control" id="sceval" type="text" name="sceval" required>
						</div>
						<div class="col-md-2">
							<label for="oleval"><b>Other Language</b></label>
							<input class="form-control" id="oleval" type="text" name="oleval" required>
						</div>
						<div class="col-md-2">
							<label for="dbeval"><b>Databases</b></label>
							<input class="form-control" id="dbeval" type="text" name="dbeval" required>
						</div>
						<div class="col-md-2">
							<label for="pseval"><b>Personal Skills</b></label>
							<input class="form-control" id="pseval" type="text" name="pseval" required>
						</div>

					</div>

					<div class="row col-sm-12 col-md-12">
						<div class="col-sm-10">
						</div>
						<div class="col-sm-2">
							<input style="margin-left: 65px;" class="btn btn-primary" type="submit" id="register" name="create" value="Sign Up">
						</div>
					</div>
			</div>
		</div>
	</form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	$(function(){
		$('#register').click(function(e){

			var valid = this.form.checkValidity();

			if(valid){

			var firstname 			 = $('#firstname').val();
			var lastname			 = $('#lastname').val();
			var street 				 = $('#street').val();
			var city 				 = $('#city').val();
			var zip 				 = $('#zip').val();
			var state 				 = $('#state').val();
			var email 				 = $('#email').val();
			var phonenumber 		 = $('#phonenumber').val();
			var skillOne    		 = $('#skillOne').val();
			var scriptlangrating     = $("input[name='scriptinglanguage']:checked").val();
			var skillTwo			 = $('#skillTwo').val();
			var otherlangrating      = $("input[name='otherlanguage']:checked").val();
			var skillThree			 = $('#skillThree').val();
			var dbrating	         = $("input[name='databases']:checked").val();
			var skillFour			 = $('#skillFour').val();
			var prsnlsklrating	     = $("input[name='psnlSkill']:checked").val();
			var sleval				 = $('#sceval').val();
			var oleval				 = $('#oleval').val(); 
			var dbeval				 = $('#dbeval').val();
			var pseval				 = $('#pseval').val();
		
				e.preventDefault();	

				$.ajax({
					type: 'POST',
					url: 'process.php',
					data: {firstname: firstname,
						   lastname: lastname,
						   street: street, 
						   city: city, 
						   zip: zip, 
						   state: state, 
						   email: email,
						   phonenumber: phonenumber, 
						   scriptinglanguage: skillOne, 
						   slrating: scriptlangrating, 
						   otherlanguage: skillTwo, 
						   olrating: otherlangrating, 
						   databases:skillThree, 
						   dbsrating: dbrating, 
						   prsnlskill: skillFour,
						   psrating: prsnlsklrating,
						   sleval: sleval,
						   oleval: oleval,
						   dbeval: dbeval,
						   pseval: pseval },
					success: function(data){

						var obj = JSON.parse(data);

						if(obj.status == 1 ){
							$('#firstname').val('');
							$('#lastname').val('');
							$('#street').val('');
							$('#city').val('');
							$('#zip').val('');
							$('#state').val('');
							$('#email').val('');
							$('#phonenumber').val('');
							$('#skillOne').val('');
							$('input[name="scriptinglanguage"]').filter(':radio').prop('checked',false);
							$('#skillTwo').val('');
							$('input[name="otherlanguage"]').filter(':radio').prop('checked',false);
							$('#skillThree').val('');
							$('input[name="databases"]').filter(':radio').prop('checked',false);
							$('#skillFour').val('');
							$('input[name="psnlSkill"]').filter(':radio').prop('checked',false);
							$('#sceval').val('');
							$('#oleval').val('');
							$('#dbeval').val('');
							$('#pseval').val('');

							Swal.fire({
								'title': 'Successful',
								'text': obj.msg,
								'type': 'success'
								})
						}else if(obj.status == 0){
							Swal.fire({
								'title': 'Error',
								'text': obj.msg,
								'icon': "warning",
								'dangerMode': true,
								'type': 'error'
								})
						}
							
					},
					error: function(data){
						Swal.fire({
								'title': 'Errors',
								'text': 'Could not save data!',
								'icon': "warning",
								'dangerMode': true,
								'type': 'error'
								})
					}
				});

				
			}

		});		

		
	});
	
</script>
</body>
</html>