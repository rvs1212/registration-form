<?php 
	/* Email credentials*/
	define('EMAIL', 'ut200ok@gmail.com');
	define('PASS', 'sendFROMpassword');
 ?> 