<?php
require 'config.php';
?>
<h3>User Info:</h3>

<?php
	$valId = $_GET["value"];
	echo '<br /><br /><a href="loginSuccess.php">back</a>'; 
?>
<br>
<br>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>

<?php
	echo "<table class='table table-striped' style='border: solid 1px black;'>";
 	echo "<tr><th>Firstname</th>
 			<th>Lastname</th>
 			<th>Street</th>
 			<th>City</th>
 			<th>Zip</th>
 			<th>State</th>
 			<th>Email</th>
 			<th>Phone</th>
 			<th>Scripting Language Evaluation</th>
 			<th>Other Language Evaluation</th>
 			<th>Databases Evaluation</th>
 			<th>Personal Skills Evaluation</th>
 		 </tr>";

	class TableRows extends RecursiveIteratorIterator {
		    function __construct($it) {
		        parent::__construct($it, self::LEAVES_ONLY);
		    }

		    function current() {
		        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
		    }

		    function beginChildren() {
		        echo "<tr>";
		    }

		    function endChildren() {
		        echo "</tr>" . "\n";
		    }
	}
	$stmt = $db->prepare("SELECT `firstname`,`lastname`,`street`,`city`,`zip`,`state`,`email`,`phonenumber`, `sleval`,`oleval`, `dbeval`, `pseval` FROM `users` WHERE id = $valId ");
    $stmt->execute();
 	$result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
 	$userInfoMain = $stmt->fetchAll();

 	$stmt = $db->prepare("SELECT `script_lang`,`other_lang`,`db_skill`,`personal_skills` FROM `users` WHERE id = $valId ");
    $stmt->execute();
    $resultNew = $stmt->setFetchMode(PDO::FETCH_ASSOC);
 	$userSkillSet = $stmt->fetchAll();

 	$userSkills = [];
 	foreach ($userSkillSet[0] as $value) {
 		$stmt = $db->prepare("SELECT `skills` FROM `skills` WHERE id = $value ");
	    $stmt->execute();
	    $resNew = $stmt->setFetchMode(PDO::FETCH_ASSOC);
	    $skillSet = $stmt->fetchAll();
 		$userSkills[] = $skillSet[0]['skills'];
 		
 	}
 	
	foreach(new TableRows(new RecursiveArrayIterator($userInfoMain)) as $key=>$val) {
        echo $val;
    }


    echo "<br><table class='table table-striped' style='border: solid 1px black;'>";
 	echo "<tr><th style='width: 27%;'>Scripting Language</th>
 			<th>Other Language</th>
 			<th>Database</th>
 			<th>Personal Skill</th>
 		 </tr>";


    class SkillTableRows extends RecursiveIteratorIterator {
		    function __construct($it) {
		        parent::__construct($it, self::LEAVES_ONLY);
		    }

		    function current() {
		        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
		    }

		    function beginChildren() {
		        echo "<tr>";
		    }

		    function endChildren() {
		        echo "</tr>" . "\n";
		    }
	}

	foreach(new TableRows(new RecursiveArrayIterator($userSkills)) as $key=>$val) {
        echo $val;
    }

?>

</body>
</html>



