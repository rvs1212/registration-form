<?php  
    require 'config.php';

    session_start();  
    if(isset($_SESSION["username"]))  
    {  
     	echo '<h3 style="text-align: center;">Welcome - '.$_SESSION["username"].'</h3>';
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>

    <h5>Registered Users:</h5>

<?php
    echo '<br /><br /><a href="logout.php">Logout</a><br /><br />';  
?>

    <table class="table table-striped">
        <tr>
            <th>UserList</th>
            <th>Skill Evaluation</th>
        </tr>

<?php
        $stmt = $db->prepare("SELECT `id`, `skill_eval_total` FROM `users`");
        $stmt->execute();
     	$result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $user_info = $stmt->fetchAll();
     	if($user_info){
            $i = 1;
            foreach($user_info as $key=>$val) {
                $skill_eval_sum = $val['skill_eval_total'];
                $usrId = $val['id']; 

                echo '<tr><td><a href="view.php?value='.$usrId.'">user-'.$i.'</a></td>&nbsp;&nbsp;';
                echo '<td>Total: '.$skill_eval_sum.'</td></tr>';
                $i++;
            }
        }else{
?>
    </table>
<?php
        echo '<h5 style="text-align: center;">No user data found!!</h5>';
        }
	
    }else  
    {  
        header("location:pdo_login.php");  
    }  
?>  

</body>
</html>